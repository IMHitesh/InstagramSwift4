//
//  ModelFile.swift
//  HSFileDownloader
//
//  Created by Hitesh on 28/05/19.
//  Copyright © 2019 Hitesh. All rights reserved.
//



import Foundation.NSURL

// Query service creates Track objects
class ImageModel {
    
    let name: String
    let previewURL: URL
    let index: Int
    var downloaded = false
    var progress = Float(0.0)
    var totalSize = "0.0 MB"

    
    
    init(name: String, previewURL: URL, index: Int) {
        self.name = name
        self.previewURL = previewURL
        self.index = index
    }
    
}


// Download service creates Download objects
class Download {
    
    var imageDetail: ImageModel
    init(imageInfo: ImageModel) {
        self.imageDetail = imageInfo
    }
    
    // Download service sets these values:
    var task: URLSessionDownloadTask?
    var isDownloading = false
    var resumeData: Data?
    
    // Download delegate sets this value:
    var progress: Float = 0
    
}

//
//  ViewController.swift
//  XMLParser
//
//  Created by Hitesh Surani on 27/05/19.
//  Copyright © 2019 HItesh. All rights reserved.
//

import UIKit


let baseURL = "http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topsongs/limit=20/xml"
class ViewController: UIViewController {

    var id = String()
    var titleValue = String()
    var audioURL = String()
    var imageURL = String()
    var elementName = String()
    
    var aryAudio = [ModelAudio]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        callAppleFeed()
    }
}


extension ViewController{
    func callAppleFeed() {
        guard let url = URL(string: baseURL) else{
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
            guard let data = data else {
                print(error.debugDescription)
                return
            }
            
            let parser = XMLParser(data: data)
            parser.delegate = self
            parser.parse()
            
        }
        task.resume()
    }
}


extension ViewController:XMLParserDelegate{
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        if elementName == ElementName.entry.rawValue{
            titleValue = String()
            audioURL = String()
        }else if elementName == ElementName.link.rawValue{
            if(attributeDict["type"] == "audio/x-m4a"){
                audioURL = attributeDict["href"] ?? ""
            }
        }else if elementName == ElementName.id.rawValue{
                id = attributeDict["im:id"] ?? ""
        }
        self.elementName = elementName
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "entry"{
            let objAudio = ModelAudio.init(id:id,title: titleValue, audioURL: audioURL, image: imageURL)
            
            HSDBManager.sharedInstance.methodToInsertUpdateDeleteData(createMultipleInsert(audio: objAudio)) { (status) in
                print(status)
            }

            aryAudio.append(objAudio)
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        
        let data = string.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
        if (!data.isEmpty) {
            if self.elementName == ElementName.title.rawValue{
                titleValue = data
            }else if self.elementName == ElementName.imimage.rawValue{
                imageURL = data
            }
        }
    }
    
    func parserDidEndDocument(_ parser: XMLParser) {
        print(aryAudio)
        
        HSDBManager.sharedInstance.methodToSelectData("SELECT * FROM XMLParser") { (aryData) in
            print(aryData)
        }
    }
    
    func createMultipleInsert(audio:ModelAudio) -> String{
        let id = audio.id!
        let title = audio.title!
        let audioURL = audio.audioURL!
        let image = audio.image!

        return "INSERT INTO XMLParser (id,title,audioURL,image) VALUES('\(id)','\(title)','\(audioURL)','\(image)')"
    }
}


struct ModelAudio {
    let id:String?
    let title:String?
    let audioURL:String?
    let image:String?
}

enum ElementName:String {
    case entry = "entry"
    case id
    case title
    case link
    case type
    case href
    case imimage = "im:image"
}
